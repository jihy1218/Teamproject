module samp {
}