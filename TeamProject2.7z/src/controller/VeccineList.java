package controller;

public interface VeccineList {

	
	void List();
	

}
